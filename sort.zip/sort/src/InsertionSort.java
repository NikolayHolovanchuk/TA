public class InsertionSort {
    public static void main(String[] args){
        int[] array = {5, 10, 2, 3, 11, 7, 4}; // инициализация массива
        for (int i = 1; i < array.length; i++){ // сортировка вставками
            int current = array[i];
            int j = i;
            while(j > 0 && array[j - 1] > current){
                array[j] = array[j - 1];
                j--;
            }
            array[j] = current;
        }
        Output(array); // вывод массива
    }

    private static void Output(int[] array){ // метод вывода отсортированного массива
        for (int step = 0; step < array.length; step++){
            System.out.println(" " + array[step]);
        }
    }
}

// время потраченное на сортировку вставками - 1239ms