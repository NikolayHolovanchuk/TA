public class SelectionSort {
    public static void main(String[] args){
        int[] array = {5, 10, 2, 3, 11, 7, 4}; // инициализация массива
        for (int step = 0; step < array.length; step++){ // сортировка выбором
            int index = min(array, step);
            int temp = array[step];
            array[step] = array[index];
            array[index] = temp;
        }
        Output(array); // вывод
    }

    private static int min(int[] array, int start){ // метод для нахождения индекса минимального элемента
        int minIndex = start;
        int minValue = array[start];
        for (int i = start + 1; i < array.length; i++){
            if (array[i] < minValue)    {
                minValue = array[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    private static void Output(int[] array){ // метод для вывода отсортрованного маассива
        for (int step = 0; step < array.length; step++){
            System.out.println(" " + array[step]);
        }
    }
}

// время потраченное на сортировку выбором - 1236ms